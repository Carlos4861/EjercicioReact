import React from 'react';

function ListaNumerica({ lista }) {
  return (
    <div>
      {lista.map((item, index) => (
        <div key={index}>{item}</div>
      ))}
    </div>
  );
}
function App() {
  const lista = ["uno", "dos", "tres", "cuatro", "cinco"];
  return (
    <div>
    <ListaNumerica lista={lista} />
    </div>
  );
}

export default App;