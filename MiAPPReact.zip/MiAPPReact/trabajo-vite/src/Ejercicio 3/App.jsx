import React from 'react';
import './App.css';

function CaptureThreeClicks() {
  const handleClick = (buttonNumber) => {
    alert(`Button ${buttonNumber} clicked!`);
  };

  return (
    <div className="capture-three-clicks-container">
      <button onClick={() => handleClick(1)}>Button 1</button>
      <button onClick={() => handleClick(2)}>Button 2</button>
      <button onClick={() => handleClick(3)}>Button 3</button>
    </div>
  );
}

export default CaptureThreeClicks;
