import React from 'react';

function CaptureClick() {
  const handleClick = () => {
    alert('Clicked!');
  };

  return (
    <div className="capture-click-container">
      <button onClick={handleClick}>Click Me</button>
    </div>
  );
}

export default CaptureClick;
