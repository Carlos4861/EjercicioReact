import React from 'react';

const bromas = [
    {
        id:1,
        setup: '¿Qué le dice un jardinero a otro?',
        punchline: '¡Qué cultivado eres!'
    },
    {
        id:2,
        setup: '¿Qué le dice una iguana a su hermana gemela?',
        punchline: '¡Iguanita!'

    }
];

const App = () => {
    return (
        <div>
            <h1>Bromas</h1>
            {bromas.map((broma) => (
                <div key={broma.id}>
                    <h3>{broma.setup}</h3>
                    <p>{broma.punchline}</p>
                </div>
            ))}
        </div>
    );
};

export default App;

    