import React, { useState } from 'react';

const GreetingForm = () => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    alert(`Hello ${firstName} ${lastName}!`);
  };

  return (
    <form onSubmit={handleSubmit} className="greeting-form">
      <label>
        First Name:
        <input
          type="text"
          value={firstName}
          onChange={(e) => setFirstName(e.target.value)}
          className="form-input"
        />
      </label>
      <label>
        Last Name:
        <input
          type="text"
          value={lastName}
          onChange={(e) => setLastName(e.target.value)}
          className="form-input"
        />
      </label>
      <button type="submit" className="submit-button">
        Greet Me
      </button>
    </form>
  );
};

export default GreetingForm;