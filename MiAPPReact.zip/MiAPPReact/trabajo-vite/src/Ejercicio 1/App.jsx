import React from 'react';
import './App.css';

function HelloWorld() {
  return (
    <div className="container">
      <div className="square">
        Hello, World!
      </div>
    </div>
  );
}

export default HelloWorld;
